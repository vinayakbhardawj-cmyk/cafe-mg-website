import Header from "../components/Header";
import Hero from "../components/Hero";
import MenuSection from "../components/MenuSection";
import Rooftop from "../components/Rooftop";
import Reviews from "../components/Reviews";
import Reserve from "../components/Reserve";
import CartSlide from "../components/CartSlide";
import Checkout from "../components/Checkout";
import Footer from "../components/Footer";
import WhatsAppFloat from "../components/WhatsAppFloat";

export default function Home() {
  return (
    <>
      <Header />
      <main>
        <Hero />
        <MenuSection />
        <Rooftop />
        <Reviews />
        <Reserve />
        <Checkout />
      </main>
      <CartSlide />
      <Footer />
      <WhatsAppFloat />
    </>
  );
}

import Header from "../components/Header";
import SellerDashboard from "./SellerDashboard";
import Footer from "../components/Footer";
import WhatsAppFloat from "../components/WhatsAppFloat";

export default function DashboardPage() {
  return (
    <>
      <Header />
      <SellerDashboard />
      <Footer />
      <WhatsAppFloat />
    </>
  );
}

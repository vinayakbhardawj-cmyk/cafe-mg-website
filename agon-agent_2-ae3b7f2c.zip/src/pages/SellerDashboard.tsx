import { useState } from "react";
import { motion } from "framer-motion";
import { Check, AlertCircle, TrendingUp, Clock, Printer } from "lucide-react";

const initialOrders = [
  { id: "ORD-101", customer: "Rakesh G.", type: "Delivery", items: "Paneer Biryani, Garlic Naan", total: 358, status: "Pending", time: "10:23 AM" },
  { id: "ORD-102", customer: "Shivani K.", type: "Rooftop", items: "Veg Biryani, Masala Chai, Butter Roti", total: 288, status: "Preparing", time: "10:45 AM" },
  { id: "ORD-103", customer: "Bhupendra S.", type: "Takeaway", items: "Sizzling Chilli Paneer Pizza, Hummus", total: 568, status: "Pending", time: "11:03 AM" },
];

export default function SellerDashboard() {
  const [orders, setOrders] = useState(initialOrders);
  const [menuStock, setMenuStock] = useState<Record<string, boolean>>({ "c1": true, "c2": true, "m10": false });

  const updateStatus = (id: string, status: string) => setOrders(prev => prev.map(o => o.id === id ? { ...o, status } : o));
  const toggleStock = (key: string) => setMenuStock(s => ({ ...s, [key]: !s[key] }));

  const todayRevenue = orders.reduce((s, o) => s + o.total, 0);

  return (
    <section className="min-h-screen bg-[#0B0B0B] pt-28 pb-20">
      <div className="max-w-7xl mx-auto px-6">
        <div className="flex items-center gap-3 mb-2"><span className="w-2 h-2 rounded-full bg-[#D4AF37] animate-pulse" /><h1 className="font-[Playfair_Display] text-4xl font-bold text-white">Seller Dashboard</h1></div>
        <p className="text-[#A0A0A0] font-[Poppins] mb-10">Live orders, menu control, and analytics for Café MG.</p>

        <div className="grid md:grid-cols-3 gap-6 mb-10">
          {[{ label: "Daily Revenue", val: "₹1,214", sub: "From active orders", icon: TrendingUp, color: "from-[#D4AF37] to-[#F2C94C]" }, { label: "Active Orders", val: orders.length.toString(), sub: "Pending / Preparing", icon: Clock, color: "from-[#3CB371] to-[#2e8b57]" }, { label: "Top Dish Today", val: "Paneer Biryani", sub: "Most ordered item", icon: TrendingUp, color: "from-[#D4AF37] to-[#F2C94C]" }].map((s, i) => (
            <div key={i} className="bg-[#151515] border border-white/[0.08] rounded-3xl p-6 hover:border-[#D4AF37]/20 transition">
              <div className="flex items-center justify-between mb-3"><span className="text-xs font-[Montserrat] font-bold tracking-widest text-[#A0A0A0] uppercase">{s.label}</span><div className={`w-9 h-9 rounded-xl bg-gradient-to-br ${s.color} flex items-center justify-center shadow-lg`}><s.icon size={18} className="text-[#0B0B0B]" /></div></div>
              <div className="font-[Playfair_Display] text-3xl font-bold text-white mb-1">{s.val}</div>
              <div className="text-sm text-[#A0A0A0] font-[Poppins]">{s.sub}</div>
            </div>
          ))}
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Order feed */}
          <div className="lg:col-span-2 bg-[#151515] border border-white/[0.08] rounded-3xl p-6 shadow-2xl shadow-black/20">
            <h2 className="font-[Playfair_Display] text-2xl font-bold text-white mb-4">Incoming Orders</h2>
            <div className="space-y-4">
              {orders.map(o => (
                <div key={o.id} className="bg-[#0B0B0B] border border-white/[0.06] rounded-2xl p-5 hover:border-[#D4AF37]/20 transition">
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2"><span className="font-[Playfair_Display] text-lg font-bold text-white">{o.id}</span><span className={`text-xs font-[Montserrat] font-bold px-2.5 py-0.5 rounded-full border ${o.status === "Pending" ? "bg-amber-500/10 text-amber-300 border-amber-500/20" : o.status === "Preparing" ? "bg-blue-500/10 text-blue-300 border-blue-500/20" : "bg-emerald-500/10 text-emerald-300 border-emerald-500/20"}`}>{o.status}</span></div>
                    <div className="font-[Playfair_Display] text-xl text-[#D4AF37] font-bold">₹{o.total}</div>
                  </div>
                  <div className="text-sm text-[#E5E5E5] mb-1"><strong>{o.customer}</strong> • {o.type}</div>
                  <div className="text-sm text-[#A0A0A0] mb-3">{o.items}</div>
                  <div className="flex items-center gap-2">
                    {o.status === "Pending" && <button onClick={() => updateStatus(o.id, "Preparing")} className="px-3 py-1.5 rounded-lg bg-[#D4AF37] text-[#0B0B0B] text-xs font-[Montserrat] font-bold hover:brightness-110">Accept</button>}
                    {o.status === "Preparing" && <button onClick={() => updateStatus(o.id, "Out for Delivery")} className="px-3 py-1.5 rounded-lg bg-[#3CB371] text-white text-xs font-[Montserrat] font-bold hover:brightness-110">Send Update</button>}
                    <button onClick={() => window.open(`https://wa.me/919876543210?text=${encodeURIComponent("Order ${o.id} is being prepared. Thank you for choosing Café MG!")}`, "_blank")} className="px-3 py-1.5 rounded-lg bg-white/[0.05] text-white text-xs font-[Montserrat] font-bold border border-white/[0.08] hover:bg-white/[0.1]">WhatsApp</button>
                    <button onClick={() => window.print()} className="px-3 py-1.5 rounded-lg bg-white/[0.05] text-white text-xs font-[Montserrat] font-bold border border-white/[0.08] hover:bg-white/[0.1] flex items-center gap-1"><Printer size={12} /> KOT</button>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Menu stock */}
          <div className="bg-[#151515] border border-white/[0.08] rounded-3xl p-6 shadow-2xl shadow-black/20 h-fit">
            <h2 className="font-[Playfair_Display] text-2xl font-bold text-white mb-4">Menu Stock</h2>
            <div className="space-y-3">
              {[
                { key: "c1", label: "Paneer Tikka Masala", price: 349 },
                { key: "c2", label: "Veg Biryani", price: 249 },
                { key: "m10", label: "Paneer Butter Masala", price: 349 },
              ].map(m => (
                <div key={m.key} className="flex items-center justify-between bg-[#0B0B0B] rounded-xl px-4 py-3 border border-white/[0.06]">
                  <div><div className="font-[Poppins] font-semibold text-white text-sm">{m.label}</div><div className="text-xs text-[#A0A0A0]">₹{m.price}</div></div>
                  <button onClick={() => toggleStock(m.key)} className={`text-xs font-[Montserrat] font-bold px-3 py-1.5 rounded-lg border transition ${menuStock[m.key] ? "bg-[#3CB371]/15 text-[#3CB371] border-[#3CB371]/30" : "bg-red-500/10 text-red-400 border-red-500/20"}`}>{menuStock[m.key] ? "In Stock" : "Out of Stock"}</button>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

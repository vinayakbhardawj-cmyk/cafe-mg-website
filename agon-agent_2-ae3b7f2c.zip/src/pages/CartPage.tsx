import Header from "../components/Header";
import Footer from "../components/Footer";
import WhatsAppFloat from "../components/WhatsAppFloat";
import { ShoppingBag, Trash2, Plus, Minus, ArrowRight } from "lucide-react";
import { Link } from "react-router-dom";

export default function CartPage() {
  return (
    <>
      <Header />
      <main className="min-h-screen bg-[#0B0B0B] pt-28 pb-20">
        <div className="max-w-3xl mx-auto px-6">
          <div className="flex items-center gap-3 mb-8"><ShoppingBag size={28} className="text-[#D4AF37]" /><h1 className="font-[Playfair_Display] text-4xl font-bold text-white">Your Cart</h1></div>
          <div className="bg-[#151515] border border-white/[0.08] rounded-3xl p-8 shadow-2xl shadow-black/30 space-y-4 mb-6">
            {[
              { name: "Paneer Tikka Masala", price: 349, qty: 1, note: "Medium spice + Extra Paneer" },
              { name: "Veg Biryani", price: 249, qty: 1, note: "No onion" },
              { name: "Garlic Naan", price: 59, qty: 2, note: "" },
            ].map((item, i) => (
              <div key={i} className="flex items-start gap-4 bg-[#0B0B0B] rounded-2xl p-4 border border-white/[0.06]">
                <div className="flex-1"><h4 className="font-[Playfair_Display] text-lg font-semibold text-white">{item.name}</h4>{item.note && <p className="text-xs text-[#D4AF37] font-[Poppins]">{item.note}</p>}<div className="text-xs text-[#A0A0A0] mt-1">₹{item.price} each</div></div>
                <div className="flex items-center gap-2"><button className="p-1 hover:text-[#D4AF37]"><Minus size={14} /></button><span className="font-[Montserrat] font-bold text-sm w-4 text-center">{item.qty}</span><button className="p-1 hover:text-[#D4AF37]"><Plus size={14} /></button></div>
                <div className="font-[Playfair_Display] text-xl font-bold text-[#D4AF37]">₹{item.price * item.qty}</div>
              </div>
            ))}
          </div>
          <div className="flex items-center justify-between p-6 bg-gradient-to-r from-[#151515] to-[#1a1a1a] border border-white/[0.08] rounded-3xl mb-6"><span className="text-xl font-[Poppins] text-[#A0A0A0]">Subtotal</span><span className="font-[Playfair_Display] text-3xl font-bold text-white">₹926</span></div>
          <div className="flex gap-4">
            <Link to="/checkout" className="flex-1 py-4 rounded-xl text-center font-[Montserrat] font-bold text-[#0B0B0B] bg-gradient-to-r from-[#D4AF37] to-[#F2C94C] hover:brightness-110 shadow-lg shadow-[#D4AF37]/20 transition">Proceed to Checkout</Link>
            <Link to="/" className="px-6 py-4 rounded-xl text-center font-[Montserrat] font-bold text-white border border-white/[0.15] hover:bg-white/[0.05] transition">Continue Ordering</Link>
          </div>
        </div>
      </main>
      <Footer />
      <WhatsAppFloat />
    </>
  );
}

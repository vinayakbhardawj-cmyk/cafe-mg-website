import { Phone } from "lucide-react";

export default function WhatsAppFloat() {
  return (
    <a href="https://wa.me/919876543210" target="_blank" rel="noopener noreferrer" aria-label="WhatsApp" className="fixed bottom-6 right-6 z-50 w-14 h-14 rounded-full bg-gradient-to-br from-[#25D366] to-[#128C7E] shadow-2xl shadow-[#25D366]/30 flex items-center justify-center text-white hover:brightness-110 transition hover:scale-105 hover:-translate-y-1" title="Chat on WhatsApp">
      <Phone size={22} />
    </a>
  );
}

import { useState, useRef, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Menu, X, Phone, ShoppingBag, User } from "lucide-react";
import { Link, useLocation } from "react-router-dom";

const navLinks = [
  { label: "Home", href: "/" },
  { label: "Menu", href: "/#menu" },
  { label: "Rooftop", href: "/#rooftop" },
  { label: "Reviews", href: "/#reviews" },
  { label: "Reserve", href: "/#reserve" },
];

export default function Header() {
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const location = useLocation();

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 60);
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    setOpen(false);
    window.scrollTo(0, 0);
  }, [location.pathname]);

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
        scrolled ? "py-3 glass-strong shadow-2xl shadow-black/40" : "py-4 glass"
      }`}
    >
      <div className="max-w-7xl mx-auto px-6 flex items-center justify-between">
        {/* Logo */}
        <Link to="/" className="flex items-center gap-3 group">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#D4AF37] to-[#9e7a2e] flex items-center justify-center shadow-lg shadow-[#D4AF37]/20 group-hover:shadow-[#D4AF37]/40 transition-all">
            <span className="font-[Playfair_Display] text-xl font-bold text-[#0B0B0B] leading-none">MG</span>
          </div>
          <div className="leading-none">
            <div className="font-[Playfair_Display] text-xl font-bold text-white tracking-tight">Café MG</div>
            <div className="text-[10px] text-[#A0A0A0] font-[Montserrat] tracking-[0.15em] uppercase">Pure Veg • Luxury</div>
          </div>
        </Link>

        {/* Desktop nav */}
        <nav className="hidden lg:flex items-center gap-1 bg-[#141414]/80 rounded-full px-2 py-1.5 border border-white/[0.06]">
          {navLinks.map((link) => (
            <a
              key={link.href}
              href={link.href}
              className="px-4 py-1.5 rounded-full font-[Poppins] text-sm text-[#E5E5E5] hover:text-white hover:bg-white/[0.08] transition-colors"
            >
              {link.label}
            </a>
          ))}
          <a href="#reserve" className="px-4 py-1.5 rounded-full font-[Montserrat] text-sm font-semibold bg-gradient-to-r from-[#D4AF37] to-[#F2C94C] text-[#0B0B0B] hover:brightness-110 transition">Reserve</a>
        </nav>

        {/* Right actions */}
        <div className="flex items-center gap-2">
          <a href="tel:+919876543210" aria-label="Call WhatsApp" className="hidden sm:inline-flex items-center gap-2 px-3 py-2 rounded-full bg-[#25D366]/15 text-[#25D366] font-[Montserrat] text-xs font-bold hover:bg-[#25D366]/25 transition border border-[#25D366]/20">
            <Phone size={14} /> WhatsApp
          </a>
          <Link to="/cart" aria-label="Cart" className="relative p-2.5 rounded-full bg-white/[0.04] hover:bg-white/[0.1] transition border border-white/[0.06]">
            <ShoppingBag size={20} className="text-[#D4AF37]" />
          </Link>
          <Link to="/seller-dashboard" aria-label="Dashboard" className="hidden md:flex p-2.5 rounded-full bg-white/[0.04] hover:bg-white/[0.1] transition border border-white/[0.06]" title="Seller Dashboard">
            <User size={20} className="text-[#D4AF37]" />
          </Link>
          <button onClick={() => setOpen(!open)} aria-label="Menu" className="lg:hidden p-2.5 rounded-full bg-white/[0.05] border border-white/[0.08] hover:bg-white/[0.1] transition">
            {open ? <X size={22} /> : <Menu size={22} />}
          </button>
        </div>
      </div>

      {/* Mobile menu */}
      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="lg:hidden overflow-hidden bg-[#0B0B0B]/98 backdrop-blur-2xl border-t border-white/[0.06]"
          >
            <nav className="flex flex-col gap-1 px-6 py-6 max-w-7xl mx-auto">
              {navLinks.map((link) => (
                <a key={link.href} href={link.href} onClick={() => setOpen(false)} className="py-3 text-lg font-[Poppins] text-[#E5E5E5] border-b border-white/[0.06] hover:text-[#D4AF37] transition">{link.label}</a>
              ))}
              <a href="/seller-dashboard" onClick={() => setOpen(false)} className="py-3 text-lg font-[Poppins] text-[#D4AF37]">Seller Dashboard</a>
              <a href="tel:+919876543210" className="mt-4 inline-flex items-center justify-center gap-2 px-4 py-3 rounded-xl bg-[#25D366] text-[#0B0B0B] font-[Montserrat] font-bold">WhatsApp Call</a>
            </nav>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
}

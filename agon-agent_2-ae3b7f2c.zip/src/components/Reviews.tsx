import { motion } from "framer-motion";
import { Star, MessageCircle } from "lucide-react";

const reviews = [
  { name: "Rakesh Ghanghas", stars: 5, text: "Absolutely incredible experience. The dal makhani and paneer tikka masala were the best we've had in Delhi. The rooftop ambiance is magical.", date: "2 days ago" },
  { name: "Shivani Khosla", stars: 5, text: "Beautiful ambiance, attentive staff, and every dish was fresh and flavorful. The pure-veg commitment gives total peace of mind. We will be coming back!", date: "1 week ago" },
  { name: "Bhupendra Sutar", stars: 5, text: "A gem hidden in Mohan Garden. From the appetizers to the desserts — everything is crafted with care. Highly recommend the paneer biryani.", date: "2 weeks ago" },
];

export default function Reviews() {
  return (
    <section id="reviews" className="relative py-28 scroll-mt-28">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-14">
          <h2 className="font-[Playfair_Display] text-4xl lg:text-6xl font-bold text-white mb-3">Guest Reviews</h2>
          <p className="text-[#A0A0A0] font-[Poppins]">Real experiences from our 173+ Google reviewers.</p>
        </div>

        <div className="grid md:grid-cols-3 gap-6 mb-14">
          {reviews.map((r, i) => (
            <motion.div key={i} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5, delay: i * 0.1 }} className="bg-[#151515] border border-white/[0.08] rounded-3xl p-7 hover:border-[#D4AF37]/30 transition shadow-lg shadow-black/20">
              <div className="flex items-center gap-1 mb-4">
                {Array.from({ length: r.stars }).map((_, j) => <Star key={j} size={16} className="text-[#D4AF37] fill-[#D4AF37]" />)}
                <span className="ml-2 text-xs font-[Montserrat] text-[#A0A0A0]">{r.date}</span>
              </div>
              <p className="text-[#E5E5E5] font-[Poppins] leading-relaxed mb-5">"{r.text}"</p>
              <div className="flex items-center gap-2 text-sm font-[Poppins] font-semibold text-white"><div className="w-7 h-7 rounded-full bg-gradient-to-br from-[#D4AF37] to-[#9e7a2e] flex items-center justify-center text-xs font-bold text-[#0B0B0B]">{r.name[0]}</div> {r.name}</div>
            </motion.div>
          ))}
        </div>

        {/* Map widget */}
        <div className="relative rounded-3xl overflow-hidden border border-white/[0.08] shadow-2xl shadow-black/40">
          <div className="aspect-[21/9] w-full bg-[#121212] relative">
            <iframe
              title="Café MG Location"
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3501.825845207548!2d77.07743317576074!3d28.65974772874075!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x390d0230a87b8a21%3A0xdbac8b2e8383e8ec!2sMohan%20Garden%2C%20New%20Delhi%2C%20Delhi!5e0!3m2!1sen!2sin!4v1719876543210!5m2!1sen!2sin"
              allowFullScreen
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
              className="w-full h-full border-0 grayscale-[0.2] contrast-125"
            />
            <div className="absolute top-4 left-4 bg-[#0B0B0B]/80 backdrop-blur-md border border-white/[0.1] rounded-2xl px-4 py-3 shadow-xl">
              <div className="font-[Playfair_Display] text-lg font-bold text-white">Café MG</div>
              <div className="text-sm text-[#E5E5E5]">Rama Park Road, Mohan Garden</div>
              <div className="text-xs text-[#A0A0A0]">West Delhi • Near Metro</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

import { useState } from "react";
import { motion } from "framer-motion";
import { Send, CheckCircle2, Clock, MapPin, Phone } from "lucide-react";

export default function Reserve() {
  const [sent, setSent] = useState(false);
  const onSubmit = (e: React.FormEvent) => { e.preventDefault(); setSent(true); setTimeout(() => setSent(false), 4000); };

  return (
    <section id="reserve" className="relative py-28 scroll-mt-28">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-20 items-start">
          <div>
            <h2 className="font-[Playfair_Display] text-4xl lg:text-6xl font-bold text-white mb-5 leading-[1.05]">Reserve Your <span className="italic text-[#D4AF37]">Table.</span></h2>
            <p className="text-[#E5E5E5]/80 text-lg font-light leading-relaxed mb-8">Book for dinner, celebrations, or a quiet rooftop evening. We'll confirm via WhatsApp within minutes. Walk-ins are always welcome.</p>
            <div className="space-y-4 mb-8">
              {[{ icon: Clock, label: "Hours", val: "11 AM – 11 PM (Daily)" }, { icon: MapPin, label: "Address", val: "Rama Park Road, Mohan Garden, West Delhi" }, { icon: Phone, label: "Call / WhatsApp", val: "+91 98765 43210" }].map((i) => (
                <div key={i.label} className="flex items-center gap-4 bg-[#151515] border border-white/[0.08] rounded-2xl p-4 hover:border-[#D4AF37]/30 transition">
                  <div className="w-10 h-10 rounded-xl bg-[#D4AF37]/10 flex items-center justify-center"><i.icon size={20} className="text-[#D4AF37]" /></div>
                  <div><div className="text-xs text-[#A0A0A0] font-[Montserrat] font-bold tracking-widest uppercase">{i.label}</div><div className="text-white font-[Poppins]">{i.val}</div></div>
                </div>
              ))}
            </div>
          </div>

          <form onSubmit={onSubmit} className="bg-[#151515] border border-white/[0.08] rounded-3xl p-8 shadow-2xl shadow-black/30">
            <h3 className="font-[Playfair_Display] text-2xl font-bold text-white mb-6">Reserve Table</h3>
            <div className="grid sm:grid-cols-2 gap-4 mb-4">
              <input required placeholder="Name" className="bg-[#0B0B0B] border border-white/[0.1] rounded-xl px-4 py-3 text-white placeholder:text-[#777] focus:outline-none focus:border-[#D4AF37]/40 font-[Poppins]" />
              <input required placeholder="Phone" className="bg-[#0B0B0B] border border-white/[0.1] rounded-xl px-4 py-3 text-white placeholder:text-[#777] focus:outline-none focus:border-[#D4AF37]/40 font-[Poppins]" />
            </div>
            <div className="grid sm:grid-cols-2 gap-4 mb-4">
              <input required placeholder="Date" type="date" className="bg-[#0B0B0B] border border-white/[0.1] rounded-xl px-4 py-3 text-white placeholder:text-[#777] focus:outline-none focus:border-[#D4AF37]/40 font-[Poppins]" />
              <input required placeholder="Guests" type="number" min={1} className="bg-[#0B0B0B] border border-white/[0.1] rounded-xl px-4 py-3 text-white placeholder:text-[#777] focus:outline-none focus:border-[#D4AF37]/40 font-[Poppins]" />
            </div>
            <textarea placeholder="Special requests (rooftop, birthday, vegan preferences)" className="w-full bg-[#0B0B0B] border border-white/[0.1] rounded-xl px-4 py-3 text-white placeholder:text-[#777] focus:outline-none focus:border-[#D4AF37]/40 font-[Poppins] mb-4 resize-none h-24" />
            <button type="submit" className={`w-full py-4 rounded-xl font-[Montserrat] font-bold text-[#0B0B0B] shadow-lg transition ${sent ? "bg-[#3CB371] shadow-[#3CB371]/20" : "bg-gradient-to-r from-[#D4AF37] to-[#F2C94C] shadow-[#D4AF37]/20 hover:brightness-110"}`}>
              {sent ? <span className="flex items-center justify-center gap-2"><CheckCircle2 size={20} /> Reservation Sent</span> : <span className="flex items-center justify-center gap-2"><Send size={18} /> Confirm Reservation</span>}
            </button>
          </form>
        </div>
      </div>
    </section>
  );
}

import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { X, Trash2, Plus, Minus, CheckCircle2, Clock, MessageCircle } from "lucide-react";

type CartItem = { id: string; name: string; price: number; qty: number; custom: string };

const initialCart: CartItem[] = [
  { id: "c1", name: "Paneer Tikka Masala", price: 349, qty: 1, custom: "Medium spice, Extra Paneer" },
  { id: "c2", name: "Veg Biryani", price: 249, qty: 1, custom: "No onion" },
  { id: "c3", name: "Garlic Naan", price: 59, qty: 2, custom: "" },
];

export default function CartSlide() {
  const [items, setItems] = useState<CartItem[]>(initialCart);
  const [open, setOpen] = useState(true);

  const change = (id: string, delta: number) => setItems(prev => prev.map(i => i.id === id ? { ...i, qty: Math.max(1, i.qty + delta) } : i));
  const remove = (id: string) => setItems(prev => prev.filter(i => i.id !== id));
  const total = items.reduce((s, i) => s + i.price * i.qty, 0);

  return (
    <>
      <div className="fixed bottom-6 left-6 z-40">
        <button onClick={() => setOpen(true)} className="flex items-center gap-2 px-4 py-3 rounded-full glass-strong shadow-2xl shadow-black/50 border border-white/[0.1] text-white font-[Montserrat] font-bold text-sm hover:border-[#D4AF37]/40 transition">
          <div className="w-6 h-6 rounded-full bg-gradient-to-r from-[#D4AF37] to-[#F2C94C] text-[#0B0B0B] flex items-center justify-center text-xs">{items.reduce((s, i) => s + i.qty, 0)}</div>
          View Cart
        </button>
      </div>

      <AnimatePresence>
        {open && (
          <motion.div initial={{ x: "100%" }} animate={{ x: 0 }} exit={{ x: "100%" }} transition={{ type: "spring", damping: 25, stiffness: 200 }} className="fixed inset-y-0 right-0 z-[70] w-full sm:w-[420px] bg-[#0B0B0B]/98 backdrop-blur-2xl border-l border-white/[0.08] shadow-2xl shadow-black/60 flex flex-col">
            <div className="flex items-center justify-between px-6 py-5 border-b border-white/[0.08]">
              <h2 className="font-[Playfair_Display] text-2xl font-bold text-white">Your Cart</h2>
              <button onClick={() => setOpen(false)} aria-label="Close" className="p-2 rounded-full bg-white/[0.05] hover:bg-white/[0.1] text-white"><X size={20} /></button>
            </div>

            <div className="flex-1 overflow-y-auto px-6 py-4 space-y-4">
              {items.map(i => (
                <div key={i.id} className="bg-[#151515] border border-white/[0.06] rounded-2xl p-4">
                  <div className="flex justify-between items-start mb-1">
                    <h4 className="font-[Playfair_Display] text-lg font-semibold text-white">{i.name}</h4>
                    <button onClick={() => remove(i.id)} aria-label="Remove" className="text-[#A0A0A0] hover:text-red-400 transition"><Trash2 size={16} /></button>
                  </div>
                  {i.custom && <p className="text-xs text-[#D4AF37] mb-2 font-[Poppins]">{i.custom}</p>}
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2 bg-[#0B0B0B] rounded-xl border border-white/[0.08] px-2 py-1">
                      <button onClick={() => change(i.id, -1)} aria-label="Decrease" className="p-1 hover:text-[#D4AF37]"><Minus size={14} /></button>
                      <span className="font-[Montserrat] text-sm font-bold w-4 text-center">{i.qty}</span>
                      <button onClick={() => change(i.id, 1)} aria-label="Increase" className="p-1 hover:text-[#D4AF37]"><Plus size={14} /></button>
                    </div>
                    <div className="font-[Playfair_Display] text-xl text-[#D4AF37] font-bold">₹{i.price * i.qty}</div>
                  </div>
                </div>
              ))}
              {items.length === 0 && <div className="text-center py-16 text-[#A0A0A0]">Cart is empty.</div>}
            </div>

            <div className="border-t border-white/[0.08] px-6 py-6 bg-[#0B0B0B]/90 backdrop-blur-md">
              <div className="flex justify-between items-end mb-4"><span className="text-[#A0A0A0] font-[Poppins]">Subtotal</span><span className="font-[Playfair_Display] text-2xl font-bold text-white">₹{total}</span></div>
              <a href="#checkout" onClick={() => setOpen(false)} className="block w-full py-4 rounded-xl text-center font-[Montserrat] font-bold text-[#0B0B0B] bg-gradient-to-r from-[#D4AF37] to-[#F2C94C] hover:brightness-110 transition shadow-lg shadow-[#D4AF37]/20">Proceed to Checkout</a>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}

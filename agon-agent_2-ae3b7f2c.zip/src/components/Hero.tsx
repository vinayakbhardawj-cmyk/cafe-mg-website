import { motion } from "framer-motion";
import { Star, MapPin, Clock, ChevronDown } from "lucide-react";

export default function Hero() {
  return (
    <section className="relative min-h-[92vh] flex items-center justify-center overflow-hidden" id="home">
      {/* Background gradient mesh */}
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_30%_20%,#1a1a2e_0%,#0B0B0B_70%)]" />
      <div className="absolute top-[-10%] right-[-10%] w-[60vw] h-[60vw] rounded-full bg-[#D4AF37]/10 blur-[120px] pointer-events-none" />
      <div className="absolute bottom-[-10%] left-[-10%] w-[50vw] h-[50vw] rounded-full bg-[#3CB371]/10 blur-[100px] pointer-events-none" />

      {/* Subtle pattern overlay */}
      <div className="absolute inset-0 opacity-[0.03]" style={{ backgroundImage: "radial-gradient(circle, #fff 1px, transparent 1px)", backgroundSize: "32px 32px" }} />

      <div className="relative z-10 max-w-6xl mx-auto px-6 py-40 text-center">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7 }}
          className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full glass text-sm font-[Poppins] text-[#E5E5E5] mb-6 border border-white/[0.08]"
        >
          <MapPin size={14} className="text-[#D4AF37]" />
          Rama Park Road, Mohan Garden — West Delhi
        </motion.div>

        <motion.h1
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.1 }}
          className="font-[Playfair_Display] text-5xl sm:text-7xl lg:text-9xl font-bold leading-[0.92] tracking-tight mb-6"
        >
          <span className="block text-white gold-text-glow">Where Every</span>
          <span className="block text-transparent bg-clip-text bg-gradient-to-r from-[#D4AF37] via-[#F2C94C] to-[#D4AF37]">Meal Becomes</span>
          <span className="block text-white/90 italic font-normal">a Memory.</span>
        </motion.h1>

        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.8, delay: 0.3 }}
          className="text-[#E5E5E5]/80 text-lg sm:text-xl max-w-2xl mx-auto mb-8 font-light leading-relaxed"
        >
          Luxury pure-veg dining in the heart of West Delhi. From handcrafted North Indian classics to artisanal rooftops — every dish tells a story.
        </motion.p>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.45 }}
          className="flex items-center justify-center gap-8 mb-10 text-sm text-[#A0A0A0]"
        >
          <span className="flex items-center gap-1.5"><Star size={14} className="text-[#D4AF37] fill-[#D4AF37]" /> 4.3★ Google</span>
          <span className="w-1 h-1 rounded-full bg-[#A0A0A0]/40" />
          <span>173+ Reviews</span>
          <span className="w-1 h-1 rounded-full bg-[#A0A0A0]/40" />
          <span>100% Pure Veg</span>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.55 }}
          className="flex flex-wrap items-center justify-center gap-4"
        >
          <a href="#reserve" className="px-8 py-3.5 rounded-full font-[Montserrat] font-bold text-[#0B0B0B] bg-gradient-to-r from-[#D4AF37] to-[#F2C94C] hover:brightness-110 transition shadow-lg shadow-[#D4AF37]/20 text-base">Book Table</a>
          <a href="#menu" className="px-8 py-3.5 rounded-full font-[Montserrat] font-bold text-white border border-white/15 hover:border-white/40 bg-white/[0.03] hover:bg-white/[0.08] transition text-base">Order Online</a>
        </motion.div>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1.2, duration: 0.6 }}
          className="mt-16 flex items-center justify-center gap-10 text-[#A0A0A0] text-sm font-[Poppins]"
        >
          <span className="flex items-center gap-2"><Clock size={16} className="text-[#D4AF37]" /> 11 AM – 11 PM</span>
          <span className="flex items-center gap-2"><Star size={16} className="text-[#D4AF37]" /> Rooftop Open</span>
          <span className="flex items-center gap-2"><MapPin size={16} className="text-[#3CB371]" /> Delivery Available</span>
        </motion.div>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1.5 }}
          className="mt-10 animate-bounce"
        >
          <a href="#menu" aria-label="Scroll to menu" className="inline-flex flex-col items-center text-[#A0A0A0] hover:text-[#D4AF37] transition text-xs tracking-widest uppercase font-[Montserrat]">
            Explore Menu <ChevronDown size={18} />
          </a>
        </motion.div>
      </div>
    </section>
  );
}

import { motion } from "framer-motion";
import { Sparkles, Coffee, Music, Users } from "lucide-react";

export default function Rooftop() {
  return (
    <section id="rooftop" className="relative py-28 overflow-hidden scroll-mt-28">
      <div className="absolute inset-0 bg-gradient-to-b from-[#0B0B0B] via-[#111] to-[#0B0B0B]" />
      <div className="absolute top-0 right-0 w-[70vw] h-[60vh] rounded-full bg-[#D4AF37]/10 blur-[140px] pointer-events-none" />

      <div className="relative max-w-7xl mx-auto px-6">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-20 items-center">
          <div>
            <div className="flex items-center gap-2 mb-3"><Sparkles size={18} className="text-[#D4AF37]" /><span className="text-xs font-[Montserrat] font-bold tracking-[0.2em] text-[#D4AF37] uppercase">Rooftop Dining</span></div>
            <h2 className="font-[Playfair_Display] text-4xl lg:text-6xl font-bold text-white mb-6 leading-[1.05]">Elevate Your Evening <span className="italic font-normal text-[#D4AF37]">Under the Stars.</span></h2>
            <p className="text-[#E5E5E5]/80 text-lg font-light leading-relaxed mb-8">Our rooftop terrace offers panoramic views of West Delhi's skyline, curated ambient lighting, and a live acoustic experience. The perfect setting for celebrations, intimate dinners, or just unwinding with friends.</p>
            <div className="grid grid-cols-3 gap-4 mb-8">
              {[
                { icon: Coffee, label: "Barista Coffee", val: "Artisan Roasts" },
                { icon: Music, label: "Live Music", val: "Evenings Daily" },
                { icon: Users, label: "Private Setup", val: "Up to 40 Guests" },
              ].map((f, i) => (
                <div key={i} className="bg-[#151515] border border-white/[0.08] rounded-2xl p-4 text-center hover:border-[#D4AF37]/30 transition">
                  <f.icon size={22} className="mx-auto text-[#D4AF37] mb-2" />
                  <div className="font-[Playfair_Display] text-sm font-bold text-white">{f.label}</div>
                  <div className="text-xs text-[#A0A0A0] font-[Poppins]">{f.val}</div>
                </div>
              ))}
            </div>
            <a href="#reserve" className="inline-block px-8 py-3.5 rounded-full font-[Montserrat] font-bold text-[#0B0B0B] bg-gradient-to-r from-[#D4AF37] to-[#F2C94C] hover:brightness-110 transition shadow-lg shadow-[#D4AF37]/20">Reserve Rooftop Table</a>
          </div>
          <div className="relative">
            <div className="rounded-3xl overflow-hidden shadow-2xl shadow-black/40 border border-white/[0.06] relative aspect-[4/3]">
              <img src="https://images.unsplash.com/photo-1559339352-11d035aa65de?q=80&w=1470&auto=format&fit=crop" alt="Luxury rooftop dining" className="w-full h-full object-cover hover:scale-[1.03] transition duration-700" loading="lazy" />
              <div className="absolute inset-0 bg-gradient-to-t from-[#0B0B0B]/60 via-transparent to-transparent" />
              <div className="absolute bottom-4 left-4 right-4 flex items-end justify-between">
                <div className="bg-[#0B0B0B]/70 backdrop-blur-md border border-white/[0.1] rounded-2xl px-4 py-3">
                  <div className="font-[Playfair_Display] text-xl font-bold text-white">7 PM — 11 PM</div>
                  <div className="text-xs text-[#A0A0A0]">Live Acoustic • Every Evening</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

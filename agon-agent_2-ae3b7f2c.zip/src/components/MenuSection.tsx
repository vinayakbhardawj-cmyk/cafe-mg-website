import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Search, Plus, Leaf, Sparkles, X } from "lucide-react";

export type MenuItem = {
  id: string;
  name: string;
  price: number;
  category: string;
  popular?: boolean;
  description?: string;
};

const categories = [
  "Soups","Starters","Rolls","Dumplings","Pasta","Pizza","Bites","Mains","Breads","South Indian","Breakfast","Rice"
];

const dishes: MenuItem[] = [
  { id: "t1", name: "Tomato Soup (Spl.)", price: 79, category: "Soups", description: "Creamy tomato with herbs" },
  { id: "t2", name: "Veg Manchow", price: 99, category: "Soups" },
  { id: "t3", name: "Sweet Corn Soup", price: 99, category: "Soups" },
  { id: "t4", name: "Hot 'n' Sour Soup", price: 99, category: "Soups" },

  { id: "s1", name: "Veg Spring Roll", price: 199, category: "Starters", popular: true },
  { id: "s2", name: "Chilli Potato", price: 199, category: "Starters" },
  { id: "s3", name: "Honey Chilli Potato", price: 199, category: "Starters" },
  { id: "s4", name: "Veg Crispy Corn", price: 199, category: "Starters" },
  { id: "s5", name: "Dry Manchurian", price: 249, category: "Starters", popular: true },
  { id: "s6", name: "Salt & Pepper", price: 249, category: "Starters" },
  { id: "s7", name: "Chilli Paneer", price: 249, category: "Starters" },
  { id: "s8", name: "Chilli Mushroom", price: 299, category: "Starters" },
  { id: "s9", name: "Paneer 65", price: 299, category: "Starters" },

  { id: "r1", name: "Soya Chaap", price: 129, category: "Rolls" },
  { id: "r2", name: "Veg Kathi", price: 129, category: "Rolls" },
  { id: "r3", name: "Paneer Tikka", price: 149, category: "Rolls" },
  { id: "r4", name: "Haryali Paneer Tikka", price: 189, category: "Rolls" },
  { id: "r5", name: "Chilli Paneer Roll", price: 189, category: "Rolls" },
  { id: "r6", name: "Malai Paneer Roll", price: 199, category: "Rolls" },

  { id: "d1", name: "Crystal Veg Dumplings", price: 249, category: "Dumplings" },
  { id: "d2", name: "Veg Chilli Oil Dumplings", price: 249, category: "Dumplings" },

  { id: "p1", name: "Arrabiata Pasta", price: 199, category: "Pasta" },
  { id: "p2", name: "Alfredo Pasta", price: 219, category: "Pasta" },
  { id: "p3", name: "Mix Sauce Pasta", price: 219, category: "Pasta" },
  { id: "p4", name: "Pesto Pasta", price: 249, category: "Pasta" },
  { id: "p5", name: "Aglio e Olio", price: 249, category: "Pasta" },
  { id: "p6", name: "Mac & Cheese", price: 249, category: "Pasta" },

  { id: "pz1", name: "Margherita", price: 299, category: "Pizza" },
  { id: "pz2", name: "Farmhouse", price: 299, category: "Pizza" },
  { id: "pz3", name: "Mexican Pizza", price: 319, category: "Pizza" },
  { id: "pz4", name: "Sizzling Chilli Paneer", price: 349, category: "Pizza", popular: true },
  { id: "pz5", name: "Paneer Tikka Pizza", price: 349, category: "Pizza" },
  { id: "pz6", name: "Spinach Tomato Olive", price: 399, category: "Pizza" },
  { id: "pz7", name: "Mushroom Truffle Oil", price: 399, category: "Pizza" },

  { id: "b1", name: "Veg Burger", price: 99, category: "Bites" },
  { id: "b2", name: "Masala Papad", price: 79, category: "Bites" },
  { id: "b3", name: "Masala Peanuts", price: 99, category: "Bites" },
  { id: "b4", name: "French Fries", price: 119, category: "Bites" },
  { id: "b5", name: "Quesadilla", price: 139, category: "Bites" },
  { id: "b6", name: "Classic Nachos", price: 149, category: "Bites" },
  { id: "b7", name: "Bruschetta", price: 149, category: "Bites" },
  { id: "b8", name: "Garlic Bread", price: 149, category: "Bites" },
  { id: "b9", name: "Veg Sandwich", price: 139, category: "Bites" },
  { id: "b10", name: "Loaded Nachos", price: 219, category: "Bites" },
  { id: "b11", name: "Hummus & Pita", price: 219, category: "Bites" },

  { id: "m1", name: "Punjabi Kadhi", price: 219, category: "Mains" },
  { id: "m2", name: "Mix Veg", price: 219, category: "Mains" },
  { id: "m3", name: "Pindi Chana", price: 229, category: "Mains" },
  { id: "m4", name: "Chaap Masala", price: 299, category: "Mains", popular: true },
  { id: "m5", name: "Dal Makhani", price: 299, category: "Mains" },
  { id: "m6", name: "Paneer Lababdar", price: 349, category: "Mains" },
  { id: "m7", name: "Kadhai Paneer", price: 349, category: "Mains" },
  { id: "m8", name: "Shahi Paneer", price: 349, category: "Mains" },
  { id: "m9", name: "Palak Paneer", price: 349, category: "Mains" },
  { id: "m10", name: "Paneer Tikka Masala", price: 349, category: "Mains" },
  { id: "m11", name: "Paneer Butter Masala", price: 349, category: "Mains" },
  { id: "m12", name: "Malai Kofta", price: 349, category: "Mains" },
  { id: "m13", name: "Matar Mushroom", price: 349, category: "Mains" },
  { id: "m14", name: "Paneer Bhurji", price: 349, category: "Mains" },

  { id: "br1", name: "Butter Roti", price: 39, category: "Breads" },
  { id: "br2", name: "Plain Naan", price: 39, category: "Breads" },
  { id: "br3", name: "Lachha Paratha", price: 49, category: "Breads" },
  { id: "br4", name: "Pudina Paratha", price: 49, category: "Breads" },
  { id: "br5", name: "Butter Naan", price: 55, category: "Breads" },
  { id: "br6", name: "Missi Roti", price: 59, category: "Breads" },
  { id: "br7", name: "Bajra Roti", price: 59, category: "Breads" },
  { id: "br8", name: "Garlic Naan", price: 59, category: "Breads" },
  { id: "br9", name: "Stuffed Paratha", price: 69, category: "Breads" },

  { id: "si1", name: "Plain Butter Dosa", price: 189, category: "South Indian" },
  { id: "si2", name: "Masala Dosa", price: 199, category: "South Indian" },
  { id: "si3", name: "Uttapam", price: 199, category: "South Indian" },
  { id: "si4", name: "Plain Idli", price: 209, category: "South Indian" },
  { id: "si5", name: "Masala Idli", price: 219, category: "South Indian" },
  { id: "si6", name: "Podi Dosa", price: 249, category: "South Indian" },
  { id: "si7", name: "Rava Dosa", price: 249, category: "South Indian" },

  { id: "bk1", name: "Poha", price: 119, category: "Breakfast" },
  { id: "bk2", name: "Chole Kulche", price: 119, category: "Breakfast" },
  { id: "bk3", name: "Chole Bhature", price: 120, category: "Breakfast" },
  { id: "bk4", name: "Aloo Paratha", price: 149, category: "Breakfast" },
  { id: "bk5", name: "Besan Chilla", price: 149, category: "Breakfast" },
  { id: "bk6", name: "Paneer Paratha", price: 199, category: "Breakfast" },
  { id: "bk7", name: "Paneer Bhurji Paratha", price: 249, category: "Breakfast" },

  { id: "rc1", name: "Plain Rice", price: 129, category: "Rice" },
  { id: "rc2", name: "Jeera Rice", price: 149, category: "Rice" },
  { id: "rc3", name: "Veg Pulao", price: 199, category: "Rice" },
  { id: "rc4", name: "Veg Biryani", price: 249, category: "Rice", popular: true },
  { id: "rc5", name: "Paneer Biryani", price: 299, category: "Rice" },
  { id: "rc6", name: "Veg Fried Rice", price: 199, category: "Rice" },
  { id: "rc7", name: "Schezwan Fried Rice", price: 249, category: "Rice" },
];

interface CustomizationState {
  spice: "Mild" | "Medium" | "Spicy";
  extraCheese: boolean;
  extraPaneer: boolean;
  dips: boolean;
  notes: string;
}

const defaultCustom: CustomizationState = { spice: "Medium", extraCheese: false, extraPaneer: false, dips: false, notes: "" };

function CustomModal({ item, onClose, onAdd }: { item: MenuItem; onClose: () => void; onAdd: (item: MenuItem, custom: CustomizationState) => void }) {
  const [c, setC] = useState<CustomizationState>({ ...defaultCustom });
  const extra = (c.extraCheese ? 40 : 0) + (c.extraPaneer ? 50 : 0) + (c.dips ? 30 : 0);
  const total = item.price + extra;

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-black/70 backdrop-blur-md" onClick={onClose}>
      <motion.div initial={{ scale: 0.95, y: 20, opacity: 0 }} animate={{ scale: 1, y: 0, opacity: 1 }} exit={{ scale: 0.95, y: 20, opacity: 0 }} onClick={e => e.stopPropagation()} className="relative w-full max-w-md rounded-3xl glass-strong p-8 shadow-2xl shadow-black/60 border border-white/[0.08]">
        <button onClick={onClose} className="absolute top-4 right-4 p-2 rounded-full bg-white/[0.05] hover:bg-white/[0.12] text-[#A0A0A0] hover:text-white transition" aria-label="Close"><X size={18} /></button>
        <div className="flex items-center gap-2 mb-1"><Leaf size={14} className="text-[#3CB371]" /><span className="text-[11px] font-[Montserrat] font-bold tracking-widest text-[#3CB371] uppercase">Pure Veg</span></div>
        <h3 className="font-[Playfair_Display] text-2xl font-bold text-white mb-1">{item.name}</h3>
        <p className="text-[#A0A0A0] text-sm mb-6">{item.description || "Handcrafted with fresh seasonal ingredients."}</p>

        <div className="space-y-5 mb-6">
          <div>
            <label className="text-xs font-[Montserrat] font-bold uppercase tracking-wider text-[#A0A0A0] mb-2 block">Spice Level</label>
            <div className="flex gap-2">
              {(["Mild","Medium","Spicy"] as const).map(s => (
                <button key={s} onClick={() => setC({ ...c, spice: s })} className={`flex-1 py-2 rounded-xl text-sm font-[Poppins] border transition ${c.spice === s ? "bg-[#D4AF37]/15 border-[#D4AF37] text-[#F2C94C]" : "bg-white/[0.03] border-white/[0.08] text-[#E5E5E5] hover:border-white/20"}`}>{s}</button>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-3 gap-2">
            {[
              { label: "Extra Cheese", price: "+₹40", key: "extraCheese" as const },
              { label: "Extra Paneer", price: "+₹50", key: "extraPaneer" as const },
              { label: "Dips", price: "+₹30", key: "dips" as const },
            ].map(opt => (
              <button key={opt.key} onClick={() => setC({ ...c, [opt.key]: !c[opt.key] })} className={`py-3 rounded-xl text-sm font-[Poppins] border transition text-center ${c[opt.key] ? "bg-[#D4AF37]/15 border-[#D4AF37] text-[#F2C94C]" : "bg-white/[0.03] border-white/[0.08] text-[#E5E5E5] hover:border-white/20"}`}>
                <div className="font-medium">{opt.label}</div>
                <div className="text-xs text-[#D4AF37] font-[Montserrat]">{opt.price}</div>
              </button>
            ))}
          </div>

          <div>
            <label htmlFor="notes" className="text-xs font-[Montserrat] font-bold uppercase tracking-wider text-[#A0A0A0] mb-2 block">Special Notes</label>
            <textarea id="notes" value={c.notes} onChange={e => setC({ ...c, notes: e.target.value })} rows={2} className="w-full bg-white/[0.04] border border-white/[0.1] rounded-xl px-3 py-2 text-sm text-white placeholder:text-[#777] focus:outline-none focus:border-[#D4AF37]/50 resize-none" placeholder="No onion, less salt..." />
          </div>
        </div>

        <div className="flex items-center justify-between pt-4 border-t border-white/[0.08]">
          <div><div className="text-xs text-[#A0A0A0] font-[Poppins]">Total</div><div className="text-xl font-[Playfair_Display] font-bold text-white">₹{total}</div></div>
          <button onClick={() => onAdd(item, c)} className="px-6 py-3 rounded-xl bg-gradient-to-r from-[#D4AF37] to-[#F2C94C] text-[#0B0B0B] font-[Montserrat] font-bold shadow-lg shadow-[#D4AF37]/20 hover:brightness-110 transition">Add to Cart</button>
        </div>
      </motion.div>
    </motion.div>
  );
}

export default function MenuSection() {
  const [search, setSearch] = useState("");
  const [activeCat, setActiveCat] = useState("Soups");
  const [modalItem, setModalItem] = useState<MenuItem | null>(null);
  const [cart, setCart] = useState<{ item: MenuItem; custom: CustomizationState; qty: number }[]>([]);

  const addToCart = (item: MenuItem, custom: CustomizationState) => {
    setCart(prev => {
      const found = prev.find(p => p.item.id === item.id && JSON.stringify(p.custom) === JSON.stringify(custom));
      if (found) return prev.map(p => p.item.id === item.id && JSON.stringify(p.custom) === JSON.stringify(custom) ? { ...p, qty: p.qty + 1 } : p);
      return [...prev, { item, custom, qty: 1 }];
    });
    setModalItem(null);
  };

  const filtered = dishes.filter(d => {
    const inCat = d.category === activeCat;
    const matches = d.name.toLowerCase().includes(search.toLowerCase()) || d.description?.toLowerCase().includes(search.toLowerCase());
    return inCat && (search ? matches : true);
  });

  return (
    <section id="menu" className="relative py-24 scroll-mt-28">
      <div className="max-w-7xl mx-auto px-6">
        <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-6 mb-12">
          <div>
            <h2 className="font-[Playfair_Display] text-4xl lg:text-6xl font-bold text-white mb-3">Digital Menu</h2>
            <p className="text-[#A0A0A0] font-[Poppins]">Browse our full collection. Every dish is 100% vegetarian with vegan options available.</p>
          </div>
          <div className="relative w-full lg:w-96">
            <Search size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-[#A0A0A0]" />
            <input value={search} onChange={e => setSearch(e.target.value)}placeholder="Search dishes..." className="w-full bg-[#151515] border border-white/[0.1] rounded-2xl pl-11 pr-4 py-3 text-white placeholder:text-[#777] focus:outline-none focus:border-[#D4AF37]/40 font-[Poppins]" />
          </div>
        </div>

        {/* Category tabs */}
        <div className="flex gap-2 overflow-x-auto pb-4 mb-10 scrollbar-none" style={{ scrollbarWidth: "none" }}>
          {categories.map(cat => (
            <button key={cat} onClick={() => setActiveCat(cat)} className={`whitespace-nowrap px-4 py-2 rounded-full font-[Montserrat] text-sm border transition ${activeCat === cat ? "bg-gradient-to-r from-[#D4AF37] to-[#F2C94C] text-[#0B0B0B] border-transparent shadow-lg shadow-[#D4AF37]/20" : "bg-[#151515] text-[#E5E5E5] border-white/[0.08] hover:border-white/20"}`}>{cat}</button>
          ))}
        </div>

        <div className="grid gap-3 md:grid-cols-2 lg:grid-cols-3">
          <AnimatePresence mode="popLayout">
            {filtered.map(item => (
              <motion.div layout key={item.id} initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0, scale: 0.95 }} transition={{ duration: 0.2 }} className="group relative bg-[#151515] hover:bg-[#181818] border border-white/[0.06] rounded-3xl p-6 transition hover:border-[#D4AF37]/30 hover:shadow-xl hover:shadow-[#D4AF37]/5">
                <div className="flex items-start justify-between mb-3">
                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      <h3 className="font-[Playfair_Display] text-xl font-semibold text-white leading-tight">{item.name}</h3>
                      {item.popular && <Sparkles size={14} className="text-[#D4AF37]" />}
                    </div>
                    <p className="text-xs text-[#A0A0A0] font-[Poppins]">{item.description || "Handcrafted daily."}</p>
                  </div>
                  <span className="font-[Playfair_Display] text-xl text-[#D4AF37] font-bold">₹{item.price}</span>
                </div>
                <div className="flex items-center justify-between pt-4 border-t border-white/[0.06]">
                  <div className="flex items-center gap-2"><Leaf size={14} className="text-[#3CB371]" /><span className="text-[10px] font-[Montserrat] font-bold text-[#3CB371] tracking-widest uppercase">Pure Veg</span></div>
                  <button onClick={() => setModalItem(item)} className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-[#D4AF37]/10 text-[#D4AF37] font-[Montserrat] text-xs font-bold hover:bg-[#D4AF37]/20 transition border border-[#D4AF37]/20"><Plus size={14} /> Add + Customize</button>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>

        {filtered.length === 0 && <div className="text-center py-16 text-[#A0A0A0]">No dishes found for this search.</div>}
      </div>

      <AnimatePresence>
        {modalItem && <CustomModal item={modalItem} onClose={() => setModalItem(null)} onAdd={addToCart} />}
      </AnimatePresence>

      {/* Floating mini cart summary */}
      <div className="fixed bottom-6 right-6 z-40">
        <a href="#cart" className="flex items-center gap-2 px-4 py-3 rounded-full glass-strong shadow-2xl shadow-black/50 border border-white/[0.1] text-white font-[Montserrat] font-bold text-sm hover:border-[#D4AF37]/40 transition">
          <div className="w-6 h-6 rounded-full bg-gradient-to-r from-[#D4AF37] to-[#F2C94C] text-[#0B0B0B] flex items-center justify-center text-xs">{cart.reduce((s, c) => s + c.qty, 0)}</div>
          Cart • ₹{cart.reduce((s, c) => s + (c.item.price + (c.custom.extraCheese ? 40 : 0) + (c.custom.extraPaneer ? 50 : 0) + (c.custom.dips ? 30 : 0)) * c.qty, 0)}
        </a>
      </div>
    </section>
  );
}

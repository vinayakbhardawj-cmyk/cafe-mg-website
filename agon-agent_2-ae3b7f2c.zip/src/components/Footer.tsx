import { Phone, ArrowUp } from "lucide-react";
import { Link } from "react-router-dom";

export default function Footer() {
  return (
    <footer className="relative bg-[#0B0B0B] border-t border-white/[0.08] pt-16 pb-6">
      <div className="max-w-7xl mx-auto px-6 grid md:grid-cols-3 gap-10 mb-12">
        <div>
          <Link to="/" className="inline-flex items-center gap-3 mb-4">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#D4AF37] to-[#9e7a2e] flex items-center justify-center shadow-lg shadow-[#D4AF37]/20"><span className="font-[Playfair_Display] text-xl font-bold text-[#0B0B0B]">MG</span></div>
            <div><div className="font-[Playfair_Display] text-xl font-bold text-white">Café MG</div><div className="text-[10px] text-[#A0A0A0] font-[Montserrat] tracking-[0.15em] uppercase">Pure Veg • Luxury</div></div>
          </Link>
          <p className="text-sm text-[#A0A0A0] font-[Poppins] leading-relaxed">Luxury pure-veg dining experience in West Delhi. Every dish handcrafted with fresh seasonal ingredients and zero compromise on quality.</p>
        </div>
        <div>
          <h4 className="font-[Montserrat] font-bold text-white mb-3 tracking-widest text-xs uppercase">Quick Links</h4>
          <div className="flex flex-wrap gap-2">
            {["Home", "Menu", "Rooftop", "Reviews", "Reserve", "Cart", "Dashboard"].map(link => (
              <a key={link} href={link === "Dashboard" ? "/seller-dashboard" : `/${link === "Cart" ? "cart" : "#" + link.toLowerCase()}`} className="text-sm text-[#A0A0A0] hover:text-[#D4AF37] font-[Poppins] transition">{link}</a>
            ))}
          </div>
        </div>
        <div>
          <h4 className="font-[Montserrat] font-bold text-white mb-3 tracking-widest text-xs uppercase">Contact</h4>
          <div className="space-y-1 text-sm text-[#E5E5E5] font-[Poppins]"><a href="tel:+919876543210" className="flex items-center gap-2 hover:text-[#D4AF37] transition"><Phone size={14} /> +91 98765 43210</a><div>Rama Park Road, Mohan Garden, West Delhi</div></div>
          <a href="https://wa.me/919876543210" target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-2 mt-3 px-4 py-2 rounded-full bg-[#25D366]/15 text-[#25D366] font-[Montserrat] font-bold text-xs border border-[#25D366]/20 hover:bg-[#25D366]/25 transition">WhatsApp Direct</a>
        </div>
      </div>
      <div className="max-w-7xl mx-auto px-6 flex flex-col md:flex-row items-center justify-between gap-4 text-xs text-[#777] font-[Poppins] border-t border-white/[0.06] pt-6">
        <div>© {new Date().getFullYear()} Café MG — Morsaab's. All rights reserved.</div>
        <button onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })} aria-label="Back to top" className="p-2.5 rounded-full bg-white/[0.05] hover:bg-white/[0.1] border border-white/[0.08] transition"><ArrowUp size={16} /></button>
      </div>
    </footer>
  );
}

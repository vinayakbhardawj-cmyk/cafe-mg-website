import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { CheckCircle2, Send, Clock, ShieldCheck, MessageCircle, ArrowRight } from "lucide-react";

export default function Checkout() {
  const [step, setStep] = useState(1); // 1 info, 2 otp, 3 done
  const [orderType, setOrderType] = useState("Delivery");
  const [otp, setOtp] = useState(["", "", "", ""]);
  const [verified, setVerified] = useState(false);
  const [timer, setTimer] = useState(60);

  const startTimer = () => { setTimer(60); const iv = setInterval(() => setTimer(t => { if (t <= 1) clearInterval(iv); return t - 1; }), 1000); };

  const submitOtp = () => { if (otp.every(d => d !== "")) { setVerified(true); setStep(3); } };

  const checkoutPayload = `Order ID: MG-${Date.now()}
Customer: Customer Name
Phone: +91 98765 43210
Order Type: ${orderType}
Items: Paneer Tikka Masala x1 (Medium + Extra Paneer), Veg Biryani x1 (No onion), Garlic Naan x2
Customizations: Extra Paneer +₹50, No onion
Total: ₹926
OTP Verified: Yes`;

  const waUrl = `https://wa.me/919876543210?text=${encodeURIComponent(checkoutPayload)}`;

  return (
    <section id="checkout" className="relative py-24 scroll-mt-28">
      <div className="max-w-3xl mx-auto px-6">
        <h2 className="font-[Playfair_Display] text-4xl lg:text-5xl font-bold text-white text-center mb-3">Checkout</h2>
        <p className="text-center text-[#A0A0A0] mb-10">Complete your order with WhatsApp verification.</p>

        <div className="bg-[#151515] border border-white/[0.08] rounded-3xl p-8 shadow-2xl shadow-black/30 mb-6">
          <div className="flex items-center gap-3 mb-6">
            {[1, 2, 3].map(s => (
              <div key={s} className={`flex-1 h-1 rounded-full transition ${step >= s ? "bg-gradient-to-r from-[#D4AF37] to-[#F2C94C]" : "bg-white/[0.1]"}`} />
            ))}
          </div>

          <AnimatePresence mode="wait">
            {step === 1 && (
              <motion.div key="step1" initial={{ opacity: 0, x: -10 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: 10 }}>
                <h3 className="font-[Playfair_Display] text-xl font-bold text-white mb-4">Order Details</h3>
                <div className="grid sm:grid-cols-2 gap-3 mb-4">
                  {["Delivery", "Takeaway", "Drive-Through", "Rooftop Table Service"].map(t => (
                    <button key={t} onClick={() => setOrderType(t)} className={`py-3 rounded-xl border text-sm font-[Poppins] transition text-center ${orderType === t ? "bg-[#D4AF37]/15 border-[#D4AF37] text-[#F2C94C] font-bold" : "bg-white/[0.03] border-white/[0.08] text-[#E5E5E5] hover:border-white/20"}`}>{t}</button>
                  ))}
                </div>
                <div className="grid sm:grid-cols-2 gap-3 mb-6">
                  <input placeholder="Name" required className="bg-[#0B0B0B] border border-white/[0.1] rounded-xl px-4 py-3 text-white placeholder:text-[#777] focus:outline-none focus:border-[#D4AF37]/40 font-[Poppins]" />
                  <input placeholder="Phone (WhatsApp)" required className="bg-[#0B0B0B] border border-white/[0.1] rounded-xl px-4 py-3 text-white placeholder:text-[#777] focus:outline-none focus:border-[#D4AF37]/40 font-[Poppins]" />
                </div>
                <div className="grid sm:grid-cols-2 gap-3 mb-6">
                  <input placeholder={orderType === "Rooftop Table Service" ? "Table / Area" : "Address"} required className="bg-[#0B0B0B] border border-white/[0.1] rounded-xl px-4 py-3 text-white placeholder:text-[#777] focus:outline-none focus:border-[#D4AF37]/40 font-[Poppins]" />
                  <input placeholder="Date (optional)" type="date" className="bg-[#0B0B0B] border border-white/[0.1] rounded-xl px-4 py-3 text-white placeholder:text-[#777] focus:outline-none focus:border-[#D4AF37]/40 font-[Poppins]" />
                </div>
                <button onClick={() => { setStep(2); startTimer(); }} className="w-full py-4 rounded-xl font-[Montserrat] font-bold text-[#0B0B0B] bg-gradient-to-r from-[#D4AF37] to-[#F2C94C] hover:brightness-110 transition shadow-lg shadow-[#D4AF37]/20">Proceed to Verify</button>
              </motion.div>
            )}

            {step === 2 && (
              <motion.div key="step2" initial={{ opacity: 0, x: -10 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: 10 }}>
                <h3 className="font-[Playfair_Display] text-xl font-bold text-white mb-2">Verify WhatsApp</h3>
                <p className="text-[#A0A0A0] text-sm mb-6">Enter the 4-digit OTP sent to your WhatsApp number to confirm.</p>
                <div className="flex gap-3 justify-center mb-4">
                  {otp.map((d, i) => (
                    <input key={i} value={d} maxLength={1} onChange={e => { const v = e.target.value.replace(/\D/, ""); const next = [...otp]; next[i] = v; setOtp(next); if (v && i < 3) document.getElementById(`otp-${i+1}`)?.focus(); }} id={`otp-${i}`} className="w-16 h-16 text-center text-2xl font-[Playfair_Display] bg-[#0B0B0B] border border-white/[0.15] rounded-2xl text-white focus:outline-none focus:border-[#D4AF37] transition" />
                  ))}
                </div>
                <div className="text-center mb-6"><span className="text-xs font-[Poppins] text-[#A0A0A0]">Resend OTP in </span><span className="font-[Montserrat] font-bold text-[#D4AF37]">{timer}s</span></div>
                <button onClick={submitOtp} className="w-full py-4 rounded-xl font-[Montserrat] font-bold text-[#0B0B0B] bg-gradient-to-r from-[#D4AF37] to-[#F2C94C] hover:brightness-110 transition shadow-lg shadow-[#D4AF37]/20">Verify & Place Order</button>
              </motion.div>
            )}

            {step === 3 && (
              <motion.div key="step3" initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} className="text-center py-6">
                <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-gradient-to-br from-[#D4AF37] to-[#F2C94C] flex items-center justify-center shadow-xl shadow-[#D4AF37]/30"><ShieldCheck size={28} className="text-[#0B0B0B]" /></div>
                <h3 className="font-[Playfair_Display] text-2xl font-bold text-white mb-2">Order Confirmed</h3>
                <p className="text-[#A0A0A0] text-sm mb-6">We are dispatching your order to WhatsApp now.</p>
                <a href={waUrl} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-2 px-8 py-3.5 rounded-full font-[Montserrat] font-bold text-[#0B0B0B] bg-[#25D366] hover:brightness-110 transition shadow-lg shadow-[#25D366]/20 mb-4"><MessageCircle size={18} /> Open WhatsApp</a>
                <div className="text-xs text-[#777] font-[Poppins]">Order payload ready at <code className="text-[#D4AF37]">wa.me/919876543210</code></div>
                <div className="mt-4 p-3 bg-[#0B0B0B] border border-white/[0.08] rounded-xl text-xs text-[#A0A0A0] font-mono text-left whitespace-pre-wrap">{checkoutPayload}</div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </section>
  );
}

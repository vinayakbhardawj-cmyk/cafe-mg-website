import { BrowserRouter, Routes, Route } from "react-router-dom";
import Home from "./pages/Home";
import SellerDashboard from "./pages/DashboardPage";
import CartPage from "./pages/CartPage";

export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/seller-dashboard" element={<SellerDashboard />} />
        <Route path="/cart" element={<CartPage />} />
        <Route path="/checkout" element={<Home />} />
      </Routes>
    </BrowserRouter>
  );
}
